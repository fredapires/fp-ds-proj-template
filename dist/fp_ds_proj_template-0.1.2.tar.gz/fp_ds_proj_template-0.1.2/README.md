# fp-ds-proj-template

Data Science project template for Frederico Pires
